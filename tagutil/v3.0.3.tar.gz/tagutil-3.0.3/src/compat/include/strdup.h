#ifndef T_COMPAT_STRDUP_H
#define T_COMPAT_STRDUP_H
/*
 * strdup.h
 *
 * return a malloc'd copy of given string.
 */


char * strdup(const char *str);

#endif /* ndef T_COMPAT_STRDUP_H */

