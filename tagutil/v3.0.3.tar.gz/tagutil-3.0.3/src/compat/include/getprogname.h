#ifndef T_COMPAT_GETPROGNAME_H
#define T_COMPAT_GETPROGNAME_H
/*
 * getprogname.h
 *
 * return the current program's name
 */


const char * getprogname(void);

#endif /* ndef T_COMPAT_GETPROGNAME_H */
